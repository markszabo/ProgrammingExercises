function [commands, map] = lookForSquares(oldMap)
    commands = {};
    map = oldMap;
end